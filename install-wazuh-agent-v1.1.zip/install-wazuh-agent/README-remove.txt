Suppression d'un agent WAZUH :

	Le script remove-wazuh-agent permet de supprimer uun agent wazuh.

	1. Arrêt de l'agent WAZUH.
	
	2. Deinstallation du package wazuh-agent (wazuh-agent-3.12.3-1.x86_64.rpm).

	3. Suppression de tous les fichiers créés par l'installation de Wazuh.

